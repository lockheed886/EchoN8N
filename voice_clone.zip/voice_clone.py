from TTS.api import TTS
import os

# -------- CONFIG --------
VOICE_SAMPLE = "myvoice.mp3"          # your recorded voice sample
BOOK_FILE = "extracted_text.txt"      # your book text file
OUTPUT_FILE = "book_voice.wav"        # final audio output
LANGUAGE = "en"                       # language code
CHUNK_SIZE = 1000                     # characters per chunk (safe for TTS)
# ------------------------

# Load XTTS-v2 model
print("Loading model... (first time may take a few mins)")
tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2", gpu=False)

# Read book text 
with open(BOOK_FILE, "r", encoding="utf-8") as f:
    text = f.read()

# Split into smaller chunks
chunks = [text[i:i+CHUNK_SIZE] for i in range(0, len(text), CHUNK_SIZE)]
print(f"Total chunks: {len(chunks)}")

# Generate audio for each chunk
temp_files = []
for idx, chunk in enumerate(chunks):
    temp_file = f"chunk_{idx}.wav"
    print(f"Generating chunk {idx+1}/{len(chunks)}...")
    tts.tts_to_file(
        text=chunk,
        file_path=temp_file,
        speaker_wav=VOICE_SAMPLE,
        language=LANGUAGE
    )
    temp_files.append(temp_file)

# Merge all chunks into one file
print("Merging audio files...")
with open(OUTPUT_FILE, "wb") as outfile:
    for fname in temp_files:
        with open(fname, "rb") as infile:
            outfile.write(infile.read())
        os.remove(fname)  # cleanup

print(f"✅ Done! Book saved as {OUTPUT_FILE}")
